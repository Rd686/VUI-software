var SpeechRecognition = SpeechRecognition || webkitSpeechRecognition
var SpeechGrammarList = SpeechGrammarList || webkitSpeechGrammarList
var SpeechRecognitionEvent = SpeechRecognitionEvent || webkitSpeechRecognitionEvent

// Output:
var synth = window.speechSynthesis;


var grammar = "#JSGF V1.0; grammar uni; public <uni> =  ...;";



//Regular expressions for the different utternaces
var u1=/.*What is (?:AR|Augmented Reality)$/i;
var u2=/.*Which app can be used to build an (?:AR|Augmented Reality)$/i;
var u3=/.*What are the real-world applications of (?:AR|Augmented Reality)$/i;

var u4=/(?:from)?\s*(.*)/i;
var u5=/(?:to)?\s*(.*)/i;


var recognition = new SpeechRecognition();
var speechGramList = new SpeechGrammarList();

recognition.continuous = false;
recognition.lang = 'en-GB';
recognition.interimResults = false;
recognition.maxAlternatives = 1;

var diagnostic = document.querySelector('.output');
var resp = document.querySelector('.response');


document.body.onclick = function() {
  resp.textContent="...";
  console.log('Ready to receive voice command.');
  enterState(0);
}


function enterState(s){
  console.log("Entering state:", s);
  // set new state
  state=s;
  
  sayState(state, function(){if(isFinal(state)){
   
  } else { recognition.start(); }});
}

// Final states:
function isFinal(s){ return s==5;}

// Things it can say in the different states.
var sayings = {
  0: "VUI - COMPUTER SCIENCE STUDIES. What would you like to learn today?",
  1:"AR stands for Augmented Reality which refers to a technology that superimposes a computer-generated image on a user's view of the real world, thus providing a composite view.",
  3:"One of the apps that can be used to build an AR is the 'Blippar' app. Blippar is a technology company that specialises in augmented reality on mobile apps and Web applications. This app allows you to create compelling augmented reality experiences or provides you with the tools to build your own.",
  5:"Some of the real-world applications of AR are as follows: (1) Games like 'Pokemon go!' make good use of AR. (2) Medical training now makes use of AR. (3) Cosmetic company Sephora uses AR technology to help customers try out different makeup looks right on their own digital face. (4) Harley Davidson is using AR to help customers in the store. (5) F-35 Helments use AR. (6) Gatwick Airport uses AR to help you find your gate. (7) AR is great for interior design and modeling."
}

function sayState(s, afterSpeechCallback){
  var textOut=sayings[s];
  resp.textContent="State: "+s+ "  "+ textOut;

  var utterThis = new SpeechSynthesisUtterance(textOut);
  utterThis.onend = function (event) {
    console.log('SpeechSynthesisUtterance.onend');
  }
  utterThis.onerror = function (event) {
    console.error('SpeechSynthesisUtterance.onerror');
  }
  utterThis.onend = afterSpeechCallback;

  synth.speak(utterThis);
}

recognition.onresult = function(event) {
  console.log('onresult');
  // The SpeechRecognitionEvent results property returns a SpeechRecognitionResultList object
  // The SpeechRecognitionResultList object contains SpeechRecognitionResult objects.
  // It has a getter so it can be accessed like an array
  // The first [0] returns the SpeechRecognitionResult at the last position.
  // Each SpeechRecognitionResult object contains SpeechRecognitionAlternative objects that contain individual results.
  // These also have getters so they can be accessed like arrays.
  // The second [0] returns the SpeechRecognitionAlternative at position 0.
  // We then return the transcript property of the SpeechRecognitionAlternative object

  var text = event.results[0][0].transcript;
  diagnostic.textContent = 'Result received: ' + text + '.';

  // figure out what they've said;
  // record slot fillers
  // what they've said + state -> new state
  // enterState(newState);

  console.log("State:", state);
  // What speech we are expecting depends on the state we're in:
  switch(state){
    case 0:
    if(text.match(u1)){ enterState(1);}
    else if (m=text.match(u3)){ startPlace = m[1]; endPlace=m[2]; enterState(5);} // "...from .... to ..."
    else if (m=text.match(u2)){ startPlace = m[1]; enterState(3);} // "...from ...."
    else {
      // re-enter the current state.
      // would be better to give an error message here as well:
      enterState(state);
    }
    break;
    case 1:
    if(m = text.match(u4)){ // "...from ...."
       enterState(3);
    } else {
      // re-enter the current state.
      // would be better to give an error message here as well:
      enterState(state);
    }
    break;

    case 3:
    if(m=text.match(u5)){
      
       enterState(5);
    } else {
      // re-enter the current state.
      // would be better to give an error message here as well:
      enterState(state);
    }
    break;

    case 5:
    break;
  }

  console.log(event.results);
  console.log('Confidence: ' + event.results[0][0].confidence);

}


// recognition.onaudiostart = function() { console.log("onaudiostart"); }
// recognition.onaudioend = function() { console.log("onaudioend"); }
//
// recognition.onsoundstart = function() { console.log("onsoundstart"); }
// recognition.onsoundend = function() { console.log("onsoundend"); }
//
// recognition.onspeechstart = function() { console.log("onspeechstart"); }
recognition.onspeechend = function() { //console.log("onspeechend");
  recognition.stop();
}

// recognition.onstart = function() { console.log("onstart"); }
// recognition.onend = function() { console.log("onsend"); }

recognition.onnomatch = function(event) {
  //console.log('onnomatch', event);
  diagnostic.textContent = "I didn't recognise that.";
}

recognition.onerror = function(event) {
  //console.log('onerror', event);
  diagnostic.textContent = 'Error occurred in recognition: ' + event.error;
}
